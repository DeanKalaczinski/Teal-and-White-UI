﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
namespace Booter_UI
{
    public partial class attackhub : Form
    {
        public attackhub()
        {
            InitializeComponent();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            home home1 = new home();

            this.Hide();

            home1.Show();
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            if (guna2TextBox4.Text != "")
            {






               

                Properties.Settings.Default.ping = guna2TextBox4.Text;
                Properties.Settings.Default.Save();

                ProcessStartInfo ps = new ProcessStartInfo();

                ps.FileName = "cmd.exe";
                ps.WindowStyle = ProcessWindowStyle.Normal;
                ps.Arguments = @"/k color b";
                ps.Arguments = @"/k ping " + Properties.Settings.Default.ping + " -t";
                Process.Start(ps);

            }

            else
            {


                MessageBox.Show("Please Insert a Target to Ping");


            }


        }
    }
}
