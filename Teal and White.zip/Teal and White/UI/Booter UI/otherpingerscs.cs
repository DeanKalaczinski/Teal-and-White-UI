﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
namespace Booter_UI
{
    public partial class otherpingerscs : Form
    {
        public otherpingerscs()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Process.Start(@"C:\Users\skate\source\repos\Booter UI\Star Pinger by RavelCros_Cro.bat");
    
           

        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            home home1 = new home();

            this.Hide();

            home1.Show();
        }

        private void guna2Button7_Click(object sender, EventArgs e)
        {
            Process.Start(@"C:\Users\skate\source\repos\Booter UI\Aqua_v3 IP Pinger.bat");

        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {
            Process.Start(@"C:\Users\skate\source\repos\Booter UI\Biohazard IP Pinger.bat");
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            Process.Start(@"C:\Users\skate\source\repos\Booter UI\Crystal pinger.bat");
        }

        private void guna2Button11_Click(object sender, EventArgs e)
        {
            Process.Start(@"C:\Users\skate\source\repos\Booter UI\IP Pinger Toxic.bat");
        }

        private void guna2Button8_Click(object sender, EventArgs e)
        {
            Process.Start(@"C:\Users\skate\source\repos\Booter UI\Space Pinger by RavelCros_Cro.bat");
        }

        private void guna2Button9_Click(object sender, EventArgs e)
        {
            Process.Start(@"C:\Users\skate\source\repos\Booter UI\Pinger_v2.3.bat");
        }
    }
}
