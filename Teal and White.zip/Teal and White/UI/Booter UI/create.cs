﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Booter_UI
{
    public partial class create : Form
    {
        public create()
        {
            InitializeComponent();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            login form1 = new login();

            this.Hide();

            form1.Show();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {


            if (guna2TextBox3.Text == Properties.Settings.Default.user && guna2TextBox4.Text == Properties.Settings.Default.user)

            {


                MessageBox.Show("Nothing Changed");



            }

            else
            {
                if (Properties.Settings.Default.user == "0" || Properties.Settings.Default.user == "0")
                {

                    MessageBox.Show("Account Created Succesfully");

                }

                else
                {

                    MessageBox.Show("Username or Password was Changed");


                }


                Properties.Settings.Default.user = guna2TextBox3.Text;
                Properties.Settings.Default.pass = guna2TextBox4.Text;
                Properties.Settings.Default.Save();

                if (guna2CheckBox1.Checked == true)
                {


                    loading form2 = new loading();

                    this.Hide();

                    form2.Show();


                }
            }
        }

        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {
           
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            if(Properties.Settings.Default.user != "0" || Properties.Settings.Default.pass != "0")
            {

                guna2Button1.Enabled = false;

                guna2Button1.Text = "Account Already Made";


            }
        }
    }
}
